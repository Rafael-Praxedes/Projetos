#ifndef CLIENT_H
#define CLIENT_H
#include "Thread.h"
#include <string>


class Client : public Thread
{
public:
    Client(Buffer& buffer, std::string IP, std::string port);
    virtual ~Client();
    void buildSocket();
    void streamVideo();
    void run();
    void destroy();

    bool stop = false;

private:

    Semaphore mutexF;

    int sock, length;
    struct sockaddr_in server;
    struct hostent *hp;

};

#endif // CLIENT_H
