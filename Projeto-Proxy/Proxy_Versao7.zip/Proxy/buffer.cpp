#include "buffer.h"

Buffer::Buffer():
    empty(BUFFER_SIZE),
    full(0)
{}

Buffer::~Buffer(){}
