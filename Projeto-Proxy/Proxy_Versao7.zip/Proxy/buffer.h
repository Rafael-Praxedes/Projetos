#ifndef BUFFER_H
#define BUFFER_H
#define DATA_SIZE 1316
#define BUFFER_SIZE 1000
#include "semaphore.h"

typedef struct{
    char frame [DATA_SIZE];
}tData;

class Buffer
{
public:
    Buffer();
    virtual ~Buffer();
    tData data[BUFFER_SIZE];
    int rear = 0;
    int front = 0;

    // Producer Consumer
    Semaphore empty;
    Semaphore full;


};

#endif // BUFFER_H
