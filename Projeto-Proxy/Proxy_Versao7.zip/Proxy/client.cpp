#include "client.h"
#include <vector>
#include <QDebug>

Client::Client(Buffer &buffer, std::string IP, std::string port):
    Thread::Thread{buffer, IP, port},
    mutexF(1)
{

}

Client::~Client(){}

void Client::run(){

    buildSocket();

    qDebug() << "Criou o client";

    while (true) {
        if(stop) return;
        buffer_.full.P();
        mutexF.P();
        streamVideo();
        mutexF.V();
        buffer_.empty.V();
    }
}

void Client::streamVideo(){
    int n;
    // Envia dados pela rede. Parametros: socket, buffer que contem os dados,
    // tamanho do buffer, flags, endereco da maquina destino, tamanho da estrutura do endereco.
    // Retorna o numero de bytes enviados.

    if(stop) return;

    n = sendto(sock, buffer_.data[buffer_.front].frame, DATA_SIZE, 0, (const struct sockaddr *) &server, length);
    buffer_.front = ( buffer_.front + 1 ) % BUFFER_SIZE;

    if (n < 0) error("Sendto");
}

void Client::buildSocket(){
    // Cria um socket do tipo datagrama e retorna um descritor
    sock = socket(AF_INET, SOCK_DGRAM, 0);

    if (sock < 0) error("socket");

    // Define a familia do endereco como do tipo Internet
    server.sin_family = AF_INET;

    // Preenche a estrutura "hp" a partir do nome da maquina ou de seu IP
    hp = gethostbyname(IP_.c_str());

    if (hp == 0) error("Unknown host");

    // Copia o IP da estrutura "hp" para a estrutura "server"
    bcopy( (char *) hp->h_addr, (char *) &server.sin_addr, hp->h_length);
    // A funcao htons() converte o numero da porta para o padrao Little Endian.
    server.sin_port = htons(atoi(port_.c_str()));

    length = sizeof(struct sockaddr_in);

}

void Client::destroy(){
    qDebug() << "Entrou no destroy";
    close(sock);
    qDebug() << "Passou de close";
    qDebug() << "Passou de terminate";
    stop = true;
}
