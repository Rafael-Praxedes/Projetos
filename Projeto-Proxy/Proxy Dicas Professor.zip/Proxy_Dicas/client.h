#ifndef CLIENT_H
#define CLIENT_H
#include "Thread.h"
#include <string.h>
#include <string>


class Client : public Thread
{
public:
    Client(Buffer& buffer, std::string IP, std::string port);
    virtual ~Client();
    void buildSocket();
    void streamVideo();
    void copyFrame();
    void run();
    void destroy();

    bool stop = false;

private:

    sem_t mutexR;

    char localFrame [DATA_SIZE];
    int sock, length;
    struct sockaddr_in server;
    struct hostent *hp;

};

#endif // CLIENT_H
