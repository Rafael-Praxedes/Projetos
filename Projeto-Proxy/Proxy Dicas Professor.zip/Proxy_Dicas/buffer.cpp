#include "buffer.h"

Buffer::Buffer()
{
    sem_init(&full, 0, 0);
    sem_init(&empty, 0, BUFFER_SIZE);
}

Buffer::~Buffer(){}
