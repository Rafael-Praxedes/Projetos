#ifndef GLOBAL_H
#define GLOBAL_H

#include "buffer.h"

extern char lim_buffer[DATA_SIZE];

#endif // GLOBAL_H
